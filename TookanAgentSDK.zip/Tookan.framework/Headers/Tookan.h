//
//  Tookan.h
//  Tookan
//
//  Created by Vipul Negi on 17/05/21.
//

#ifndef Tookan_h
#define Tookan_h

#import <Foundation/Foundation.h>
#import <GoogleMaps/GoogleMaps.h>
#import "FBShimmering.h"
#import "FBShimmeringLayer.h"
#import "FBShimmeringView.h"
#import "ifaddrs.h"
//! Project version number for Tookan.
FOUNDATION_EXPORT double TookanVersionNumber;

//! Project version string for Tookan.
FOUNDATION_EXPORT const unsigned char TookanVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Tookan/PublicHeader.h>


#endif
